/******************************************************************************/
/* This file was taken from STLport <www.stlport.org> and modified by         */
/* Texas Instruments.                                                         */
/******************************************************************************/

#if defined (_STLP_MSVC) || defined (__ICL)

#  pragma warning (pop)
#  pragma pack (pop)

#endif
